// FARDIN App Scripts

document.addEventListener('DOMContentLoaded', () => {
    const settingsBtn = document.getElementById('settings-btn');
    const closeSettings = document.getElementById('close-settings');
    const settingsModal = document.getElementById('settings-modal');
    const avatarToggle = document.getElementById('avatar-toggle');
    const avatarContainer = document.getElementById('floating-avatars-container');

    // Toggle Settings Modal
    settingsBtn.addEventListener('click', () => settingsModal.classList.remove('hidden'));
    closeSettings.addEventListener('click', () => settingsModal.classList.add('hidden'));

    // Create 5 Floating Avatars
    function initFloatingAvatars() {
        avatarContainer.innerHTML = '';
        for (let i = 1; i <= 5; i++) {
            const avatar = document.createElement('div');
            avatar.className = 'floating-avatar';
            avatar.style.animationDelay = `${i * 0.4}s`;
            avatar.innerHTML = `<span style="font-size: 20px;">🤖</span>`;
            avatar.title = `Avatar Speaker ${i}`;

            avatar.addEventListener('click', () => {
                alert(`FARDIN Floating Avatar ${i} (Speaker Activated)`);
            });

            avatarContainer.appendChild(avatar);
        }
    }

    // Avatar Visibility Toggle
    avatarToggle.addEventListener('change', (e) => {
        if (e.target.checked) {
            avatarContainer.style.display = 'flex';
        } else {
            avatarContainer.style.display = 'none';
        }
    });

    initFloatingAvatars();
});
